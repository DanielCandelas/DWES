<?php

echo "<form action='' method='POST'>";
echo "<br> DNI: <br> <input type='text' name='dni'><br/>";
echo "<br> Contraseña: <br> <input type='text' name='pwd'><br/>";
echo "<br> <input type='submit' name='enviarPwd'>";
echo "</form>";