<?php

echo $mensaje;