<?php
	
	echo "<h1>Consulta en nuestra Web Online</h1>";
	echo "<form action='' method='post' >";	
	echo "ID Producto: <input type='text' name='id'><br>";
	echo "<input type='submit' name='enviarApi'> <br> </form>";