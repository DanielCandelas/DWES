<?php

echo $dato;