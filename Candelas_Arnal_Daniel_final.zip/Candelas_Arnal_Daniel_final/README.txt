
cambiar url para la funcion al mover de sitio

si se le cambia el nombre a index.php hay que cambiar la referencia en enlace.php

fichero txt con el json que devuelve la consulta por la api con el ID 846